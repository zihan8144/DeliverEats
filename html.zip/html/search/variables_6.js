var searchData=
[
  ['total_5fdeliveries',['total_deliveries',['../structDailyStats.html#a50d642f1cca8b41b2c530f277fd2da8d',1,'DailyStats']]],
  ['total_5fmoney',['total_money',['../structDailyStats.html#ae9322976d21e256111b43784640ab7e7',1,'DailyStats']]]
];
