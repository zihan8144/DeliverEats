var searchData=
[
  ['write_5fdaily_5fsummary',['write_daily_summary',['../main_8cpp.html#ab1dfdbffe7f19e98466a47e02b3977fd',1,'main.cpp']]]
];
