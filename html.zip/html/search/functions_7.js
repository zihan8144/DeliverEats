var searchData=
[
  ['reset',['reset',['../structDailyStats.html#ab78b2edaf02fcc4ef08004e5c6eab63b',1,'DailyStats']]],
  ['reset_5fdaily_5fmileage',['reset_daily_mileage',['../classDelivery__Rider.html#ac38363e8d06ba42e25f20943b6c41f51',1,'Delivery_Rider']]]
];
