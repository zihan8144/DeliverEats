var searchData=
[
  ['speed',['speed',['../classDelivery__Rider.html#a2343aa36100740983ad9174c0a04abc8',1,'Delivery_Rider']]]
];
