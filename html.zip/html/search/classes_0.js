var searchData=
[
  ['activedelivery',['ActiveDelivery',['../structActiveDelivery.html',1,'']]]
];
