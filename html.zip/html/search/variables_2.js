var searchData=
[
  ['max_5fdistance',['max_distance',['../classDelivery__Rider.html#a64ed254ad9f54ea3405a5f7e894db826',1,'Delivery_Rider']]],
  ['missed_5forders',['missed_orders',['../structDailyStats.html#a74d510b8d2e4c76290283c4c40a80316',1,'DailyStats']]],
  ['moped_5fdeliveries',['moped_deliveries',['../structDailyStats.html#a4eec64cccb33b76876f7183c37a2f336',1,'DailyStats']]],
  ['moped_5fmoney',['moped_money',['../structDailyStats.html#a919ed0b415413941ca372eb16c5a69ff',1,'DailyStats']]]
];
