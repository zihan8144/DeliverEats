var searchData=
[
  ['calculate_5ftime',['calculate_time',['../classDelivery__Rider.html#aaa973747a42918fa4d5aaba0ea6ea123',1,'Delivery_Rider']]],
  ['can_5ftake_5forder',['can_take_order',['../classDelivery__Rider.html#aea0c1caf20ce515fcef293d6fc43ad29',1,'Delivery_Rider']]]
];
