var searchData=
[
  ['activedelivery',['ActiveDelivery',['../structActiveDelivery.html',1,'']]],
  ['add_5fdistance',['add_distance',['../classDelivery__Rider.html#a14c3757da2d28026eeb2c65aa48718a4',1,'Delivery_Rider']]]
];
