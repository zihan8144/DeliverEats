var searchData=
[
  ['dailystats',['DailyStats',['../structDailyStats.html',1,'']]],
  ['delivery_5frider',['Delivery_Rider',['../classDelivery__Rider.html',1,'Delivery_Rider'],['../classDelivery__Rider.html#aae5f78c4c7f822b2b4cd8b234582bec6',1,'Delivery_Rider::Delivery_Rider()']]]
];
