var searchData=
[
  ['delivery_5frider',['Delivery_Rider',['../classDelivery__Rider.html#aae5f78c4c7f822b2b4cd8b234582bec6',1,'Delivery_Rider']]]
];
