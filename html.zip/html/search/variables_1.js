var searchData=
[
  ['cost_5fpriority',['COST_PRIORITY',['../main_8cpp.html#afcb711a378a129804101a493316a1752',1,'main.cpp']]],
  ['cost_5fstandard',['COST_STANDARD',['../main_8cpp.html#aacd7eb127d6982d4931caf86da4d5723',1,'main.cpp']]],
  ['current_5fdistance',['current_distance',['../classDelivery__Rider.html#ac14a04e6f01048a03440e29fc32c47f8',1,'Delivery_Rider']]]
];
