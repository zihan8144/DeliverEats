var searchData=
[
  ['update_5freturning_5friders',['update_returning_riders',['../main_8cpp.html#a44064ccb4d7167968d907d40ed68e851',1,'main.cpp']]]
];
