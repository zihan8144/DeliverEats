var searchData=
[
  ['_7edelivery_5frider',['~Delivery_Rider',['../classDelivery__Rider.html#af1dd53971d056c8954a441f020dd94d9',1,'Delivery_Rider']]]
];
