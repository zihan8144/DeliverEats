var searchData=
[
  ['get_5fname',['get_name',['../classDelivery__Rider.html#a74a08a08a6e1178f2dee1ef4d89aa2a4',1,'Delivery_Rider']]],
  ['get_5foutput_5ffilename',['get_output_filename',['../main_8cpp.html#a4a648a71b4e8db7355a47df6853800bb',1,'main.cpp']]],
  ['get_5fvehicle_5ftype',['get_vehicle_type',['../classDelivery__Rider.html#a6b8f352d3e992128e93409e5ce41ea87',1,'Delivery_Rider']]]
];
