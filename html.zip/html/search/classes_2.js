var searchData=
[
  ['dailystats',['DailyStats',['../structDailyStats.html',1,'']]],
  ['delivery_5frider',['Delivery_Rider',['../classDelivery__Rider.html',1,'']]]
];
