var searchData=
[
  ['return_5ftime',['return_time',['../structActiveDelivery.html#ad9f7995f2f97228a9443f1908456f0d7',1,'ActiveDelivery']]],
  ['rider',['rider',['../structActiveDelivery.html#af0fb51925403180495b3af72f3533fef',1,'ActiveDelivery']]]
];
